﻿using System.ComponentModel;

namespace POCSearchFilter.ViewModel
{
    public class BaseViewModel : INotifyPropertyChanged
    {
        #region Event

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
           PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
