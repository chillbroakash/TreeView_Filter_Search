﻿using POCSearchFilter.Model;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace POCSearchFilter.ViewModel
{
    public class MainViewModel : BaseViewModel
    {

        #region Private Member Variables

        private ObservableCollection<Plant> _filteredPlants;
        private ObservableCollection<Plant> _originalPlants;
        private Device _namurStatus;
        private bool _isSearchApply;
        private bool _isFilterOpened;
        private string _devicePAVSearch;

        #endregion

        #region Public Member Variables

        public ObservableCollection<Device> _devices = new ObservableCollection<Device>();

        #endregion

        #region Public Properties

        public ObservableCollection<Plant> FilteredPlants
        {
            get
            {
                return _filteredPlants;
            }
            set
            {
                if (_filteredPlants != value)
                {
                    _filteredPlants = value;
                    OnPropertyChanged(nameof(FilteredPlants));
                }
            }
        }

        public ObservableCollection<Plant> OriginalPlants
        {
            get
            {
                return _originalPlants;
            }
            set
            {
                if (_originalPlants != value)
                {
                    _originalPlants = value;
                    OnPropertyChanged(nameof(OriginalPlants));
                }
            }
        }

        public Device NamurStatus
        {
            get
            {
                return _namurStatus;
            }
            set
            {
                _namurStatus = value;
                OnPropertyChanged(nameof(NamurStatus));
            }
        }

        public string PAVSearchDevice
        {
            get => _devicePAVSearch;
            set
            {
                _devicePAVSearch = value;
                SearchTreeView();
                OnPropertyChanged(nameof(PAVSearchDevice));
                if (!string.IsNullOrWhiteSpace(value))
                {
                    IsSearchApply = false;
                }
            }
        }

        public bool IsSearchApply
        {
            get => _isSearchApply;
            set
            {
                _isSearchApply = value;
                OnPropertyChanged(nameof(IsSearchApply));
            }
        }

        public bool IsFilterOpened
        {
            get
            {
                return _isFilterOpened;
            }
            set
            {
                _isFilterOpened = value;
                OnPropertyChanged("IsFilterOpened");
            }
        }

        #endregion

        #region ICommand

        private ICommand _filterCommand;

        public ICommand FilterCommand
        {
            get
            {
                if (_filterCommand == null)
                {
                    _filterCommand = new RelayCommand(CanExecute, FilterPopCommand);
                }
                return _filterCommand;
            }

        }

        private ICommand _ApplyBtnCommand;

        public ICommand ApplyBtnCommand
        {
            get
            {
                if (_ApplyBtnCommand == null)
                {
                    _ApplyBtnCommand = new RelayCommand(CanExecute, ApplyCommand);
                }
                return _ApplyBtnCommand;
            }

        }

        #endregion

        #region Constructor

        public MainViewModel()
        {
            InitializeData();
            NamurStatus = new Device();
        }

        #endregion

        #region Public Methods


        public ObservableCollection<Device> GenerateDevices(int count)
        {
            var devices = new ObservableCollection<Device>();
            for (int i = 1; i <= count; i++)
            {
                Device device = new Device { Name = $"Device{i}" };

                int randomStatus = new Random().Next(7);

                switch (randomStatus)
                {
                    case 1:
                        device.Connected = true;
                        break;
                    case 2:
                        device.DisConnected = true;
                        break;
                    case 3:
                        device.Healthy = true;
                        break;
                    case 4:
                        device.Failure = true;
                        break;
                    case 5:
                        device.CheckFunction = true;
                        break;
                    case 6:
                        device.MaintRequ = true;
                        break;
                    case 0:
                        device.OutofSpec = true;
                        break;
                }

                devices.Add(device);
            }

            return devices;
        }

        #endregion

        #region Private Method

        private void ApplyCommand(object parameter)
        {
            try
            {
                bool connected = NamurStatus.Connected;
                bool disConnected = NamurStatus.DisConnected;
                bool healthy = NamurStatus.Healthy;
                bool failure = NamurStatus.Failure;
                bool checkFunction = NamurStatus.CheckFunction;
                bool mainReq = NamurStatus.MaintRequ;
                bool outoFsepc = NamurStatus.OutofSpec;

                if (!connected && !disConnected && !healthy && !failure && !checkFunction && !mainReq && !outoFsepc)
                {
                    FilteredPlants = new ObservableCollection<Plant>();
                    FilteredPlants = OriginalPlants;
                    IsFilterOpened = false;
                    return;
                }

                var filteredPlantList = new ObservableCollection<Plant>();

                var filteredPlants = OriginalPlants.Where(plant =>
                {
                    foreach (var area in plant.Areas)
                    {
                        foreach (var unit in area.Units)
                        {
                            List<Device> devices = unit.Devices.Where(device =>
                                (connected && device.Connected) || (disConnected && device.DisConnected) || (healthy && device.Healthy) || (failure && device.Failure) || (checkFunction && device.CheckFunction) || (outoFsepc && device.OutofSpec) || (mainReq && device.MaintRequ)).ToList();

                            var deviceList = new ObservableCollection<Device>(devices);

                            var plantItem = new Plant
                            {
                                Name = plant.Name,
                                Areas = new ObservableCollection<Area>
                                {
                                    new Area
                                    {
                                        Name = area.Name,
                                        Units = new ObservableCollection<Unit>
                                        {
                                            new Unit
                                            {
                                                Name = unit.Name,
                                                Devices = deviceList
                                            }
                                        }
                                    }
                                }
                            };

                            filteredPlantList.Add(plantItem);
                        }
                    }

                    return plant.Areas.Any(area => area.Units.Any(unit => unit.Devices.Any()));
                }).ToList();

                FilteredPlants = new ObservableCollection<Plant>(filteredPlantList);
                IsFilterOpened = false;

                filteredPlants = new List<Plant>();
                foreach (var plant in FilteredPlants)
                {
                    var filteredAreas = new List<Area>();
                    foreach (var area in plant.Areas)
                    {
                        var filteredUnits = new List<Unit>();
                        foreach (var unit in area.Units)
                        {
                            var filteredDevices = FilterDevices(unit.Devices, PAVSearchDevice);
                            if (filteredDevices.Any())
                            {
                                var filteredUnit = new Unit
                                {
                                    Name = unit.Name,
                                    Devices = new ObservableCollection<Device>(filteredDevices)
                                };
                                filteredUnits.Add(filteredUnit);
                            }
                        }

                        if (filteredUnits.Any())
                        {
                            var filteredArea = new Area
                            {
                                Name = area.Name,
                                Units = new ObservableCollection<Unit>(filteredUnits)
                            };
                            filteredAreas.Add(filteredArea);
                        }
                    }

                    if (filteredAreas.Any())
                    {
                        var filteredPlant = new Plant
                        {
                            Name = plant.Name,
                            Areas = new ObservableCollection<Area>(filteredAreas)
                        };
                        filteredPlants.Add(filteredPlant);
                    }
                }

                FilteredPlants = new ObservableCollection<Plant>(filteredPlants);
            }
            catch (Exception ex)
            {
                // Handle the exception
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        private void SearchTreeView()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(PAVSearchDevice))
                {
                    ApplyCommand(FilterDevices);
                    return;
                }

                ApplyCommand(FilterDevices);
                var filteredPlants = new List<Plant>();
                foreach (var plant in FilteredPlants)
                {
                    var filteredAreas = new List<Area>();
                    foreach (var area in plant.Areas)
                    {
                        var filteredUnits = new List<Unit>();
                        foreach (var unit in area.Units)
                        {
                            var filteredDevices = FilterDevices(unit.Devices, PAVSearchDevice);
                            if (filteredDevices.Any())
                            {
                                var filteredUnit = new Unit
                                {
                                    Name = unit.Name,
                                    Devices = new ObservableCollection<Device>(filteredDevices)
                                };
                                filteredUnits.Add(filteredUnit);
                            }
                        }

                        if (filteredUnits.Any())
                        {
                            var filteredArea = new Area
                            {
                                Name = area.Name,
                                Units = new ObservableCollection<Unit>(filteredUnits)
                            };
                            filteredAreas.Add(filteredArea);
                        }
                    }

                    if (filteredAreas.Any())
                    {
                        var filteredPlant = new Plant
                        {
                            Name = plant.Name,
                            Areas = new ObservableCollection<Area>(filteredAreas)
                        };
                        filteredPlants.Add(filteredPlant);
                    }
                }

                FilteredPlants = new ObservableCollection<Plant>(filteredPlants);
            }
            catch (Exception ex)
            {
                // Handle the exception
                Console.WriteLine($"An error occurred in SearchTreeView: {ex.Message}");
            }
        }

        private IEnumerable<Device> FilterDevices(IEnumerable<Device> devices, string searchString)
        {
            return devices.Where(device =>
                device.Name.IndexOf(searchString, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void FilterPopCommand(object arg)
        {
            if (IsFilterOpened)
            {
                IsFilterOpened = false;
            }
            else
            {
                IsFilterOpened = true;
            }
        }

        private bool CanExecute(object obj)
        {
            return true;
        }

        private void InitializeData()
        {
            OriginalPlants = new ObservableCollection<Plant>
                {
                    new Plant
                    {
                        Name = "Plant 1",
                        Areas = new ObservableCollection<Area>
                        {
                            new Area
                            {
                                Name = "Area 1",
                                Units = new ObservableCollection<Unit>
                                {
                                    new Unit
                                    {
                                        Name = "Unit",
                                        Devices = GenerateDevices(120)
                                    }
                                }
                            }
                        }
                    }
                };

            FilteredPlants = new ObservableCollection<Plant>(_originalPlants);
        }

        #endregion
    }
}