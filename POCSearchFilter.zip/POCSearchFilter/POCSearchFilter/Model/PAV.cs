﻿using POCSearchFilter.ViewModel;
using System.Collections.ObjectModel;

namespace POCSearchFilter.Model
{
    public class Plant : BaseViewModel
    {
        #region Public Member Variables

        public string Name { get; set; }
        public ObservableCollection<Area> Areas { get; set; }

        #endregion
    }

    public class Area : BaseViewModel
    {
        #region Public Member Variables

        public string Name { get; set; }
        public ObservableCollection<Unit> Units { get; set; }

        #endregion
    }

    public class Unit : BaseViewModel
    {
        #region Public Member Variables

        public string Name { get; set; }
        public ObservableCollection<Device> Devices { get; set; }

        #endregion
    }

    public class Device : BaseViewModel
    {
        #region Private Member Variables

        private string _Name;
        private bool _Healthy;
        private bool _Connected;
        private bool _DisConnected;
        private bool _CheckFunction; 
        private bool _Failure;
        private bool _OutofSpec;
        private bool _MaintRequ;

        #endregion

        #region Public Properties

        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
      
        public bool Healthy
        {
            get
            {
                return _Healthy;
            }
            set
            {
                _Healthy = value;
                OnPropertyChanged(nameof(Healthy));
            }
        }
       
        public bool Connected
        {
            get
            {
                return _Connected;
            }
            set
            {
                _Connected = value;
                OnPropertyChanged(nameof(Connected));
            }
        }
       
        public bool DisConnected
        {
            get
            {
                return _DisConnected;
            }
            set
            {
                _DisConnected = value;
                OnPropertyChanged(nameof(DisConnected));
            }
        }
      
        public bool CheckFunction
        {
            get
            {
                return _CheckFunction;
            }
            set
            {
                _CheckFunction = value;
                OnPropertyChanged(nameof(CheckFunction));
            }
        }
        
        public bool Failure
        {
            get
            {
                return _Failure;
            }
            set
            {
                _Failure = value;
                OnPropertyChanged(nameof(Failure));
            }
        }
      
        public bool OutofSpec
        {
            get
            {
                return _OutofSpec;
            }
            set
            {
                _OutofSpec = value;
                OnPropertyChanged(nameof(OutofSpec));
            }
        }
        
        public bool MaintRequ
        {
            get
            {
                return _MaintRequ;
            }
            set
            {
                _MaintRequ = value;
                OnPropertyChanged(nameof(MaintRequ));
            }
        }

        #endregion
    }
}


