﻿using System.Windows.Controls;

namespace POCSearchFilter.CustomControls
{
    public class CustomSearchTextBox : TextBox
    {
        private bool _isClear;

        public bool isClear
        {
            get
            {
                return _isClear;
            }
            set
            {
                _isClear = value;
                Text = string.Empty;
            }
        }

    }
}
