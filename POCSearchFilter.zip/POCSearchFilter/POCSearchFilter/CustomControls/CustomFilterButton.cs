﻿using System.Windows;
using System.Windows.Controls;

namespace POCSearchFilter.CustomControls
{
    public class CustomFilterButton : Button
    {
        public int FilterCount
        {
            get
            {
                return (int)GetValue(SetTextProperty);
            }
            set
            {
                SetValue(SetTextProperty, value);
            }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SetTextProperty =
            DependencyProperty.Register("FilterCount", typeof(int), typeof(CustomFilterButton), new PropertyMetadata(0, new PropertyChangedCallback(OnTextChanged)));

        private static void OnTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

        }
    }
}
